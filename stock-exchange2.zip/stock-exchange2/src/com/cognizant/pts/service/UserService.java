package com.cognizant.pts.service;

public interface UserService {

	int doLogin(UserModel userModel);
}
