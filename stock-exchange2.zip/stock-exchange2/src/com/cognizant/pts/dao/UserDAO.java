package com.cognizant.pts.dao;

import com.cognizant.pts.entity.User;

public interface UserDAO {

	int doLogin(User user);
}
