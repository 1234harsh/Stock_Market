package com.cognizant.pts.model;

public class StockExchangeModel {

	private String stockexchange_id;
	private String stockExchange;
	private String brief;
	private String contactAddress;
	private String remarks;
	public String getStockexchange_id() {
		return stockexchange_id;
	}
	public void setStockexchange_id(String stockexchange_id) {
		this.stockexchange_id = stockexchange_id;
	}
	public String getStockExchange() {
		return stockExchange;
	}
	public void setStockExchange(String stockExchange) {
		this.stockExchange = stockExchange;
	}
	public String getBrief() {
		return brief;
	}
	public void setBrief(String brief) {
		this.brief = brief;
	}
	public String getContactAddress() {
		return contactAddress;
	}
	public void setContactAddress(String contactAddress) {
		this.contactAddress = contactAddress;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	
	
}
